package com.cris.wagon_master.module;

import com.orchestranetworks.service.LoggingCategory;

public class Logger {

	public static LoggingCategory logger;
}
