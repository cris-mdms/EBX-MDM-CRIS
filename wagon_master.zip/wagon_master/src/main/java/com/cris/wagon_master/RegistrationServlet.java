package main.java.com.cris.wagon_master;

import com.orchestranetworks.module.ModuleRegistrationServlet;
import com.orchestranetworks.module.ModuleServiceRegistrationContext;

public class RegistrationServlet extends ModuleRegistrationServlet {
	private static final long serialVersionUID = 1L;

	public void handleServiceRegistration(ModuleServiceRegistrationContext aContext) {
	}
}